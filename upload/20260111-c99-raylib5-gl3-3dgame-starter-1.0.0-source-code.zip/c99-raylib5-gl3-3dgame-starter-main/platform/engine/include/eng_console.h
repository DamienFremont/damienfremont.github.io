#include <stdbool.h>

#pragma once

//---------------------------------------------------------
// Module Functions Declaration
//---------------------------------------------------------

void LogConsole(const char* str);
void DrawConsole();
