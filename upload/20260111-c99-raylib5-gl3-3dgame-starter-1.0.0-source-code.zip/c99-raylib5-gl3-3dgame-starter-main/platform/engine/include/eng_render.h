#include <raylib.h>

#pragma once

//---------------------------------------------------------
// Module Functions Declaration
//---------------------------------------------------------

void Draw_PostProcessing(Shader postproShader, const RenderTexture2D *target);
