#include <raylib.h>

#include "eng_config.h"

//---------------------------------------------------------
// Module Functions Declaration
//---------------------------------------------------------

Shader TileTexture2D(Vector2 tiling);
