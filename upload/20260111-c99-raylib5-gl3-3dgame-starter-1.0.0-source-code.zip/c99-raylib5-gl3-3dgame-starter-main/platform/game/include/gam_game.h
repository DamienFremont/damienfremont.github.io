#include "eng_config.h"

#pragma once

//---------------------------------------------------------
// Module Functions Declaration
//---------------------------------------------------------

int main(AppConfiguration appProps);
