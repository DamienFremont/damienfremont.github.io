#pragma once

//---------------------------------------------------------
// Module Functions Declaration
//---------------------------------------------------------

void Init_Menu();
int Update_Menu();
void Draw_Menu();
void Unload_Menu();
